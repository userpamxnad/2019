# What is Net2ftp?
Net2ftp is a web based FTP client, written in PHP.

# Latest Stable
The latest stable version is 1.1 released in June 2017.

# Full Vs Light Version
The full version contains all plugins while the light version only contains the Java upload plugin.

# Download
You can download it from this github or from its download page at: https://www.net2ftp.com/homepage/download.html

# Changelog
All of its changelog including the latest one can be seen here at: https://www.net2ftp.com/download/_CHANGES_v1.1.txt
